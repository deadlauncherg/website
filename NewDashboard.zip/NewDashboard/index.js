const express = require("express");
const path = require("path");
const session = require("express-session"); // ✅ Needed for req.session
const bodyParser = require("body-parser");

const app = express();

// Middleware
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

// ✅ Setup sessions
app.use(
  session({
    secret: "chunkhost_secret_key",
    resave: false,
    saveUninitialized: true,
  })
);

// Set EJS as view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Serve CSS and JS from /views
app.use("/css", express.static(path.join(__dirname, "views")));
app.use("/js", express.static(path.join(__dirname, "views")));

// In-memory user store (temporary)
const users = [];

// Routes
app.get("/", (req, res) => {
  res.render("home", {
    title: "ChunkHost - Premium Hosting",
    page: "home",
    user: req.session.user || null,
  });
});

app.get("/minecraft", (req, res) => {
  res.render("minecraft", {
    title: "ChunkHost - Minecraft Hosting",
    page: "minecraft",
    user: req.session.user || null,
  });
});

app.get("/vps", (req, res) => {
  res.render("vps", {
    title: "ChunkHost - VPS Hosting",
    page: "vps",
    user: req.session.user || null,
  });
});

app.get("/domains", (req, res) => {
  res.render("domains", {
    title: "ChunkHost - Domain Services",
    page: "domains",
    user: req.session.user || null,
  });
});

app.get("/pricing", (req, res) => {
  res.render("pricing", {
    title: "ChunkHost - Pricing Plans",
    page: "pricing",
    user: req.session.user || null,
  });
});

app.get("/minecraftserv", (req, res) => {
  const plan = req.query.plan || "basic";
  res.render("minecraftserv", {
    user: req.session.user || null,
    page: "minecraftserv",
    title: "Minecraft Server Setup - ChunkHost",
    selectedPlan: plan,
  });
});

// ✅ Auth page route
app.get("/auth", (req, res) => {
  res.render("auth", {
    user: req.session.user || null,
    page: "auth",
    title: "Login & Register - ChunkHost",
  });
});

// ✅ Auth status check
app.get("/api/auth-status", (req, res) => {
  res.json({
    loggedIn: !!req.session.user,
    user: req.session.user || null,
  });
});

// ✅ Login
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ success: false, message: "Email and password are required" });
  }

  const user = users.find((u) => u.email === email && u.password === password);
  if (!user) {
    return res.status(401).json({ success: false, message: "Invalid credentials" });
  }

  req.session.user = { id: user.id, name: user.name, email: user.email };
  res.json({ success: true, message: "Login successful!", user: req.session.user });
});

// ✅ Register
app.post("/api/register", (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ success: false, message: "All fields are required" });
  }

  if (password.length < 6) {
    return res.status(400).json({ success: false, message: "Password must be at least 6 characters" });
  }

  const existingUser = users.find((u) => u.email === email);
  if (existingUser) {
    return res.status(400).json({ success: false, message: "User already exists" });
  }

  const newUser = { id: Date.now().toString(), name, email, password, createdAt: new Date() };
  users.push(newUser);

  req.session.user = { id: newUser.id, name: newUser.name, email: newUser.email };
  res.json({ success: true, message: "Registration successful!", user: req.session.user });
});

// ✅ Logout route
app.get("/logout", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/");
  });
});

// In your Express
app.get('/minecraftserv', (req, res) => {
    // Check if user is logged in
    if (!req.session.user) {
        return res.redirect('/auth');
    }

    const plan = req.query.plan || 'premium';
    const price = parseInt(req.query.price) || 199;

    // Make sure user object exists and has required properties
    const user = req.session.user || {};

    res.render('minecraftserv', {
        user: user,
        plan: plan,
        price: price,
        title: `Minecraft ${plan} Plan - Payment`
    });
});

// pricing.js routes
app.get('/pricing', (req, res) => {
    res.render('pricing', {
        user: req.session.user,
        title: 'Pricing - ChunkHost'
    });
});

app.get('/vps', (req, res) => {
    res.render('vps', {
        user: req.session.user,
        title: 'VPS Hosting - ChunkHost'
    });
});

app.get('/domains', (req, res) => {
    res.render('domains', {
        user: req.session.user,
        title: 'Domain Registration - ChunkHost'
    });
});

// Support Route
app.get('/support', (req, res) => {
    res.render('support', {
        user: req.session.user,
        title: 'Support - ChunkHost'
    });
});

// ✅ Server start (auto fallback if port in use)
const PORT = process.env.PORT || 3006;

function startServer(port) {
  const server = app.listen(port, () => {
    console.log(`✅ ChunkHost running at http://localhost:${port}`);
  });

  server.on("error", (err) => {
    if (err.code === "EADDRINUSE") {
      console.log(`⚠️ Port ${port} in use, trying port ${port + 1}...`);
      startServer(port + 1); // recursively try next port
    } else {
      console.error("Server error:", err);
    }
  });
}

startServer(PORT);
